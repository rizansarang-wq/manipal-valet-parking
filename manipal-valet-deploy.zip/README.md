# Manipal Hospitals — Valet Parking (Prototype)

Single-file static web app. No build step, no dependencies — `index.html` is the entire site.

## Deploy to Vercel (fastest — no GitHub needed)

1. Go to https://vercel.com/new
2. Drag and drop this folder (or just `index.html`) onto the page
3. Click **Deploy** — you'll get a live `.vercel.app` URL in ~30 seconds

## Deploy via GitHub + Vercel (if you want version history / future edits via git)

```bash
# from inside this folder
git init
git add .
git commit -m "Initial commit: valet parking prototype"
gh repo create manipal-valet-parking --public --source=. --push
# (or push manually to a repo you create on github.com)
```

Then in Vercel:
1. https://vercel.com/new → "Import Git Repository"
2. Select the `manipal-valet-parking` repo → Deploy
3. Framework preset: **Other** (it's static HTML, no build command needed)

## Notes
- Data is stored via the in-app storage API used during our chat session — once deployed standalone on Vercel, that storage will no longer be connected. You'll want a real backend (e.g. Supabase/Postgres) before this is used for real bookings. Happy to wire that up next.
- OTP is still simulated on-screen; staff login is still the demo PIN. Swap these for a real SMS gateway and staff auth before go-live.
